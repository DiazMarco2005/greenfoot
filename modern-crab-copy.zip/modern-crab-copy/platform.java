import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class platform here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class platform extends Actor
{
    public platform() {
        GreenfootImage image = new GreenfootImage("platform.jpeg");
        image.scale(30, 30);// Asegúrate de tener una imagen llamada "platform.png" en la carpeta de imágenes
        setImage(image);
    }
    
    public void act()
    {
        // Add your action code here.
    }
}
